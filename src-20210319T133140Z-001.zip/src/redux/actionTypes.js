export default {
  SAVE_USER_DATA: 'SAVE_USER_DATA',
};
