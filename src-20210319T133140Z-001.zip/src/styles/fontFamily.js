
export default {
    regular:"SFProText-Regular",
    bold:"SFProText-Bold",
    medium:"Futura-Medium",
    futuraHeavyBt:"Futura Hv BT",
    futuraBtHeavy:"FuturaBT-Heavy",
    futuraBook:"Futura-Book",
    futura:"Futura-Normal",
    semiBold:"SFProText-SemiBold"
}



