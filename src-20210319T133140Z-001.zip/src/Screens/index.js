export {default as Login} from './Login/Login';
export {default as SignUp} from './SignUp/SignUp';
export {default as LandingPage} from './LandingPage/LandingPage';
export {default as AuthPage} from './AuthPage/AuthPage';
export {default as Home} from './Home/Home';
export {default as OtpVerification} from './OtpVerification/OtpVerification';

