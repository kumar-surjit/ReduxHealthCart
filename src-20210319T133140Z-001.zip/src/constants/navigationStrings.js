export default {
  Login: 'Login',
  SignUp: 'SignUp',
  LandingPage: 'LandingPage',
  AuthPage: 'AuthPage',
  Home: 'Home',
  OtpVerification: 'OtpVerification'
};
